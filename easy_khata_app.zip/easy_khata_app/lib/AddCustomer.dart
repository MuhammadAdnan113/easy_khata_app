import 'package:flutter/material.dart';

class AddCustomer extends StatefulWidget {
  @override
  State<AddCustomer> createState() => _AddCustomerState();
}

class _AddCustomerState extends State<AddCustomer> {
  @override
  Widget build(Object context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(
        children: [
          Container(
            height: 60,
            margin: EdgeInsets.all(10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(
                  width: 10,
                ),
                CircleAvatar(
                  child: Icon(
                    Icons.minimize,
                  ),
                  foregroundColor: Color.fromARGB(255, 255, 255, 255),
                  backgroundColor: Color.fromARGB(255, 241, 35, 55),
                ),
                SizedBox(
                  width: 8,
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Rs 0',
                      style: TextStyle(
                        color: Color.fromARGB(255, 0, 171, 34),
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                    ),
                    Text(
                      'Hisab clear hai',
                      style: TextStyle(
                        color: Color.fromARGB(255, 15, 201, 52),
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
          const SizedBox(height: 10),
          Container(
            height: 400,
            child: ListView(
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Center(
                        child: Text(
                            'Customer ka hisab kitab shuru karny k lye pehli entry darj krein')),
                  ],
                ),
              ],
              shrinkWrap: true,
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ElevatedButton.icon(
                onPressed: () {},
                icon: Icon(Icons.arrow_upward_outlined),
                label: Text('MAINE DIYE'),
              ),
              ElevatedButton.icon(
                onPressed: () {},
                icon: Icon(Icons.arrow_downward_outlined),
                label: Text('MAINE LIYE'),
              ),
            ],
          )
        ],
      ),
    );
  } // end State
}// end Class
