import 'package:easy_khata_app/CashIN.dart';
import 'package:easy_khata_app/MyHomePage.dart';
import 'package:easy_khata_app/PoranaRecord.dart';
import 'package:flutter/material.dart';

class CashBook extends StatefulWidget {
  @override
  State<CashBook> createState() => _CashBookState();
}

class _CashBookState extends State<CashBook> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SingleChildScrollView(
        child: Column(children: [
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(),
              Container(
                height: 70,
                width: 170,
                color: const Color.fromARGB(255, 238, 235, 235),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Text(
                        'RS 0',
                        style: TextStyle(
                          color: Color.fromARGB(255, 0, 171, 34),
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                      Text(
                        'Cash in Hand',
                        style: TextStyle(
                          color: Color.fromARGB(255, 15, 201, 52),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                height: 70,
                width: 170,
                color: const Color.fromARGB(255, 238, 235, 235),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Text(
                        'RS 0',
                        style: TextStyle(
                          color: Color.fromARGB(255, 0, 171, 34),
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                      Text(
                        'Aj ka balance',
                        style: TextStyle(
                          color: Color.fromARGB(255, 15, 201, 52),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 10,
          ),
          ElevatedButton.icon(
            onPressed: () {
              _goToNextScreen(context);
            },
            icon: const Icon(Icons.note_alt_rounded),
            label: const Text('Porana record'),
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: const [
              Text('9th June,2022'),
              Text('Cash Out'),
              Text('Cash In'),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            height: 300,
            child: ListView(
              children: [
                const Text('Adnan'),
              ],
              shrinkWrap: true,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ElevatedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.exposure_minus_1),
                label: const Text('CASH OUT'),
              ),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.of(context)
                      .push(MaterialPageRoute(builder: (context) => CashIn()));
                },
                icon: const Icon(Icons.add),
                label: const Text('CASH IN'),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              GestureDetector(
                onTap: () {
                  _goToNextScreen(context);
                },
                child: Column(
                  children: const [
                    Icon(Icons.menu_book),
                    SizedBox(
                      height: 8,
                    ),
                    Text(
                      'Khata',
                      style: TextStyle(fontSize: 17),
                    ),
                  ],
                ),
              ),
              Column(
                children: const [
                  Icon(Icons.book_outlined),
                  SizedBox(
                    height: 8,
                  ),
                  Text(
                    'Cashbook',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                  ),
                ],
              ),
              Column(
                children: const [
                  Icon(Icons.person_outline),
                  SizedBox(
                    height: 8,
                  ),
                  Text(
                    'Account',
                    style: TextStyle(fontSize: 17),
                  ),
                ],
              ),
            ],
          ),
        ]),
      ),
    );
  } // end state

  void _goToNextScreen(BuildContext context) {
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (context) => PoranaRecord()));
  }
}// end Class
