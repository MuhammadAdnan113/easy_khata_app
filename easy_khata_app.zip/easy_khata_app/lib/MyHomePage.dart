import 'package:easy_khata_app/AddCustomer.dart';
import 'package:easy_khata_app/VisitingCard.dart';
import 'package:flutter/material.dart';

import 'CashBook.dart';

class MyHomePage extends StatefulWidget {
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  TextEditingController search = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(
                  height: 10,
                  width: 10,
                ),
                Container(
                  color: Colors.red.shade100,
                  height: 60,
                  width: 170,
                  child: Row(
                    children: [
                      const CircleAvatar(
                        child: Icon(
                          Icons.arrow_downward_rounded,
                        ),
                        foregroundColor: Color.fromARGB(255, 255, 255, 255),
                        backgroundColor: Color.fromARGB(255, 241, 35, 55),
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Text(
                            'RS 0',
                            style: TextStyle(
                              color: Color.fromARGB(255, 241, 35, 55),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Main ny Leny hain',
                            style: TextStyle(
                              color: Color.fromARGB(255, 241, 35, 55),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Container(
                  height: 60,
                  width: 170,
                  color: Colors.green.shade100,
                  child: Row(
                    children: [
                      const CircleAvatar(
                        child: Icon(
                          Icons.arrow_upward_rounded,
                        ),
                        foregroundColor: Color.fromARGB(255, 255, 255, 255),
                        backgroundColor: Color.fromARGB(255, 5, 220, 51),
                      ),
                      Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Text(
                            'RS 0',
                            style: TextStyle(
                              color: Color.fromARGB(255, 5, 220, 51),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Main ny Leny hain',
                            style: TextStyle(
                              color: Color.fromARGB(255, 8, 199, 68),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            GestureDetector(
              onTap: () {
                Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => VisitingCard()));
              },
              child: Container(
                width: double.maxFinite,
                height: 50,
                margin: const EdgeInsets.all(10),
                color: const Color.fromARGB(255, 204, 200, 200),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: const [
                    Text(
                        'Apny karobar ki pehchan banaen,\nBussines Card banaen!'),
                    Icon(Icons.card_giftcard_outlined),
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Row(
              children: const [
                Icon(Icons.search_outlined),
                // TextField(
                //   controller: search,
                //   decoration: InputDecoration(
                //     hintText: 'Search Customer',
                //     prefixIcon: Icon(Icons.search_off_outlined),
                //   ),
                // ),
              ],
            ),
            const SizedBox(
              height: 10,
            ),
            Container(
              height: 300,
              child: ListView(
                children: const [
                  Text('Adnan'),
                ],
                shrinkWrap: true,
              ),
            ),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.of(context).push(
                    MaterialPageRoute(builder: (context) => AddCustomer()));
              },
              icon: Icon(Icons.add),
              label: Text('Add Customer'),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  children: const [
                    Icon(Icons.menu_book),
                    SizedBox(
                      height: 8,
                    ),
                    Text(
                      'Khata',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
                    ),
                  ],
                ),
                GestureDetector(
                  onTap: () {
                    _goToNextScreen(context);
                  },
                  child: Column(
                    children: const [
                      Icon(Icons.book_outlined),
                      SizedBox(
                        height: 8,
                      ),
                      Text(
                        'Cashbook',
                        style: TextStyle(fontSize: 17),
                      ),
                    ],
                  ),
                ),
                Column(
                  children: const [
                    Icon(Icons.person_outline),
                    SizedBox(
                      height: 8,
                    ),
                    Text(
                      'Account',
                      style: TextStyle(fontSize: 17),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  } // end build

  void _goToNextScreen(BuildContext context) {
    Navigator.of(context)
        .push(MaterialPageRoute(builder: (context) => CashBook()));
  }
} // end Class
