import 'package:flutter/material.dart';

class PoranaRecord extends StatefulWidget {
  @override
  State<PoranaRecord> createState() => _PoranaRecordState();
}

class _PoranaRecordState extends State<PoranaRecord> {
  @override
  Widget build(Object context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(
        children: [
          const SizedBox(
            height: 10,
          ),
          Row(
            children: [
              Container(
                height: 50,
                width: 160,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(Icons.note_sharp),
                    Text('9th June, 22'),
                  ],
                ),
              ),
              const SizedBox(
                width: 1,
              ),
              Container(
                height: 50,
                width: 160,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Icon(Icons.note_add),
                    Text('9th June, 22'),
                  ],
                ),
              ),
              const SizedBox(
                width: 30,
              ),
              Container(
                height: 50,
                width: 50,
                child: const Icon(Icons.notes_sharp),
              ),
            ],
          ),
          const SizedBox(
            height: 10,
          ),
          Container(
            height: 50,
            margin: EdgeInsets.all(10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Text('Total In'),
                    Text(
                      'RS 50',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: Color.fromARGB(255, 5, 167, 73),
                      ),
                    ),
                  ],
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Text('Total Out'),
                    Text(
                      'RS 50',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: Colors.red,
                      ),
                    ),
                  ],
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: const [
                    Text('Net Balance'),
                    Text(
                      'RS 50',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: Color.fromARGB(255, 5, 167, 73),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: const [
              Text('Date'),
              Text('Cash in hand'),
              Text('Balance'),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            height: 300,
            child: ListView(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: const [
                        Text('9th June,2022'),
                      ],
                    ),
                    Column(
                      children: const [
                        Text('Rs 50'),
                      ],
                    ),
                    Column(
                      children: const [
                        Text('Rs 50'),
                      ],
                    )
                  ],
                ),
              ],
              shrinkWrap: true,
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          const SizedBox(
            height: 50,
          ),
          ElevatedButton(onPressed: () {}, child: const Text('Download Report'))
        ],
      ),
    );
  } // end State
}// end Class
