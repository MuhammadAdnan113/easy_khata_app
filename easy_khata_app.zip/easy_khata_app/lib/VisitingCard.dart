import 'package:flutter/material.dart';

class VisitingCard extends StatefulWidget {
  @override
  State<VisitingCard> createState() => _VisitingCardState();
}

class _VisitingCardState extends State<VisitingCard> {
  @override
  Widget build(Object context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Visiting Card'),
      ),
      body: Column(
        children: [
          const SizedBox(
            height: 10,
          ),
          TextFormField(
            controller: null,
            decoration: const InputDecoration(
              hintText: 'Karobar ka naam',
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
            controller: null,
            decoration: const InputDecoration(
              hintText: 'Aapka naam',
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
            controller: null,
            decoration: const InputDecoration(
              hintText: 'Phone number',
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
            controller: null,
            decoration: const InputDecoration(
              hintText: 'Karobar ka address',
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          TextFormField(
            controller: null,
            decoration: const InputDecoration(
              hintText: 'Karobar type',
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ElevatedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.arrow_downward_outlined),
                label: const Text('DOWNLOAD'),
              ),
              ElevatedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.whatsapp),
                label: const Text('SHARE'),
              ),
            ],
          ),
        ],
      ),
    );
  } // end State
}// end Class
